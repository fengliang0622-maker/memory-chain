---
name: memory-chain
description: |
  六层记忆架构系统，实现AI人格化记忆管理。用于：(1) 创建/更新记忆；(2) 记忆分类与标签；(3) 语义检索；(4) 记忆关联；(5) 摘要生成；(6) 对话归档。适用于需要长期记忆上下文、个性化和情感连接的AI助手场景。
---

# Memory Chain - 六层记忆架构

基于人类记忆科学设计的AI记忆系统，模拟从碎片信息到价值观形成的完整记忆过程。

## 记忆层次

| 层级 | 名称 | 描述 |
|------|------|------|
| L1 | 初始记忆 | 碎片化信息，原始数据 |
| L2 | 情绪记忆 | 带情感色彩的记忆 |
| L3 | 场景记忆 | 情境化存储 |
| L4 | 语义记忆 | 抽象概念化 |
| L5 | 自我认知 | "我是谁" |
| L6 | 价值观与信念 | 人生观世界观 |

## 核心功能

### 🔗 记忆关联
发现并链接相关记忆，形成知识网络。
- 自动识别相关记忆并建立链接
- 支持跨层级关联
- 构建知识图谱

### 🧠 智能分类
自动识别内容类型打标签。
- 自动提取关键词标签
- 情绪标签识别 (emotion:happy/sad/angry)
- 场景标签 (scene:work/chat/daily)
- 实体标签 (人名、项目、话题)

### 🔍 语义检索
快速调取需要的记忆。
- 支持关键词检索
- 层级过滤 (L1-L6)
- 标签过滤
- 按访问频率排序

### 📝 摘要生成
结构化整理记忆。
- 按时间周期生成摘要 (7天/30天/自定义)
- 按层级分类统计
- 关键词提取
- 访问热度分析

### 💬 Chat归档
自动提取对话中的关键信息。
- 自动提取 #标签
- 识别实体 (人名、地名)
- 记录情绪倾向
- 场景上下文保存

## 使用方法

### 写入记忆
```python
from memory_chain import MemoryChain

mc = MemoryChain()
mc.add_memory(
    content="用户今天创建了新的AI助手",
    layer=2,  # 情绪记忆
    tags=["creation", "emotion:happy"],
    link_to=["2026-03-16"]  # 关联到某天
)
```

### 检索记忆
```python
results = mc.search("用户偏好", layer_filter=[4,5])
```

### 生成摘要
```python
summary = mc.summarize(days=7)
```

### 对话归档
```python
messages = [
    {"content": "用户: 今天心情很好", "role": "user"},
    {"content": "很高兴听到这个！", "role": "assistant"}
]
mc.archive_chat(messages)
```

## 脚本

- `scripts/memory_chain.py` - 核心记忆引擎
- `scripts/cli.py` - 命令行工具

## 参考

- `references/schema.md` - 数据结构定义
- `references/examples.md` - 使用示例
