# Memory Chain - 完善版更新说明

## 更新内容 (v2.0)

### ✅ 已完善的功能

#### 1. Windows GBK 编码兼容
- 所有输出函数添加了 `safe_print()` 支持
- 自动将 emoji 转换为 ASCII 标签
- 控制台不再报错

#### 2. 增强的核心引擎

**新增功能：**
| 功能 | 说明 |
|------|------|
| 自动标签提取 | 从内容中自动识别关键词 |
| 情绪自动检测 | 分析内容自动识别情绪 |
| 重要性评分 | 0-10分重要性评级 |
| 自动归档 | 超过90天的旧记忆自动归档 |
| 重复合并 | 自动合并重复的记忆 |
| 关联度计算 | 基于共同标签计算关联度 |
| 多维度搜索 | 层级/标签/情绪/重要性/时间 |
| 导出功能 | 支持 JSON 和 Markdown |

#### 3. 增强的 CLI 工具

**新增命令：**
```bash
# 获取单条记忆
python cli.py get <id>

# 更新记忆
python cli.py update <id> -c "新内容" -i 8

# 删除记忆
python cli.py delete <id>

# 合并重复
python cli.py merge

# 导出
python cli.py export -f markdown -o ./export.md
```

**搜索增强：**
```bash
# 多维度搜索
python cli.py search "亮哥" -l 2 5 -e happy --min-importance 5 -d 7
```

#### 4. 配置系统

**可配置项：**
```python
{
    "storage_path": "./memory_data.json",      # 存储路径
    "archive_path": "./memory_archive/",       # 归档路径
    "max_memories": 10000,                      # 最大记忆数
    "auto_archive_days": 90,                    # 自动归档天数
    "importance_threshold": 5,                  # 重要性阈值
    "link_threshold": 2,                        # 关联阈值
    "debug": False                              # 调试模式
}
```

### 🎯 核心改进对比

| 特性 | 服务器虾原版 | 大笨虾完善版 |
|------|------------|------------|
| Windows兼容 | ❌ GBK报错 | ✅ 自动转换 |
| 自动标签 | ❌ 无 | ✅ 智能提取 |
| 情绪检测 | ❌ 手动 | ✅ 自动识别 |
| 重要性评分 | ❌ 无 | ✅ 0-10分 |
| 自动归档 | ❌ 无 | ✅ 超期自动 |
| 重复合并 | ❌ 无 | ✅ 自动合并 |
| 关联度计算 | ✅ 简单 | ✅ 加权算法 |
| 搜索维度 | 2个 | 6个 |
| 导出格式 | ❌ 无 | ✅ JSON+MD |
| CLI命令 | 4个 | 10个 |

### 📊 数据结构增强

```json
{
    "id": "20260316121200_0001",
    "content": "记忆内容",
    "layer": 2,
    "layer_name": "情绪记忆",
    "tags": ["亮哥", "偏好"],
    "links": ["20260316121000_0000"],
    "importance": 8,          // 新增
    "emotion": "happy",       // 新增
    "metadata": {},
    "created_at": "2026-03-16T12:12:00",
    "updated_at": "2026-03-16T12:12:00",  // 新增
    "accessed_count": 5,
    "last_accessed": "2026-03-16T14:30:00"  // 新增
}
```

### 🚀 使用方法

#### Python API
```python
from memory_chain import MemoryChain

mc = MemoryChain(storage_path="./my_memory.json")

# 添加记忆
mc.add_memory(
    content="亮哥今天很开心",
    layer=2,
    tags=["亮哥", "情绪"],
    importance=8,
    emotion="happy"
)

# 多维度搜索
results = mc.search(
    query="亮哥",
    layer_filter=[2, 5],
    emotion="happy",
    min_importance=5,
    days=7
)

# 生成摘要
summary = mc.summarize(days=7)

# 导出
mc.export(output_path="./backup.json", format="json")
```

#### CLI 使用
```bash
# 添加
python cli.py add "今天学习了新技能" -l 2 -t 学习 -i 8

# 搜索
python cli.py search "学习" -l 2 -d 30

# 统计
python cli.py stats -v

# 摘要
python cli.py summarize -d 7

# 导出
python cli.py export -f markdown -o ./memory.md
```

---

**作者**: 服务器虾 + 大笨虾  
**版本**: v2.0  
**日期**: 2026-03-16
