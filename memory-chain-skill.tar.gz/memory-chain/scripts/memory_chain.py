#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Memory Chain - 六层记忆架构核心引擎 (增强版)
Author: 服务器虾 + 大笨虾
"""

import json
import os
import re
import sys
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any, Tuple
from pathlib import Path
from collections import Counter

# 兼容Windows GBK编码
def safe_print(text: str):
    """安全打印，兼容GBK编码"""
    try:
        print(text)
    except UnicodeEncodeError:
        # 移除emoji，替换为ASCII
        replacements = {
            '✅': '[OK]',
            '❌': '[X]',
            '🔍': '[Search]',
            '📊': '[Stats]',
            '📝': '[Note]',
            '🔗': '[Link]',
            '🧠': '[Brain]',
            '💾': '[Save]',
            '⚡': '[!]',
            '🎯': '[Target]',
        }
        for emoji, ascii_alt in replacements.items():
            text = text.replace(emoji, ascii_alt)
        print(text)


class MemoryChain:
    """六层记忆架构引擎 - 增强版"""
    
    LAYERS = {
        1: "初始记忆",
        2: "情绪记忆", 
        3: "场景记忆",
        4: "语义记忆",
        5: "自我认知",
        6: "价值观与信念"
    }
    
    LAYER_DESCRIPTIONS = {
        1: "碎片化信息，原始数据点",
        2: "带情感色彩的经历和感受",
        3: "情境化存储，时空标记",
        4: "抽象概念和知识体系",
        5: "身份认同，我是谁",
        6: "人生观、世界观、核心价值观"
    }
    
    # 默认配置
    DEFAULT_CONFIG = {
        "storage_path": "./memory_data.json",
        "archive_path": "./memory_archive/",
        "max_memories": 10000,
        "auto_archive_days": 90,  # 超过90天的记忆自动归档
        "importance_threshold": 5,  # 重要性阈值
        "link_threshold": 2,  # 关联阈值（共同标签数）
        "debug": False
    }
    
    def __init__(self, storage_path: str = None, config: Dict = None):
        """初始化记忆引擎"""
        self.config = {**self.DEFAULT_CONFIG, **(config or {})}
        if storage_path:
            self.config["storage_path"] = storage_path
        
        self.storage_path = self.config["storage_path"]
        self.archive_path = self.config["archive_path"]
        self.memories = self._load()
        self._ensure_archive_dir()
    
    def _ensure_archive_dir(self):
        """确保归档目录存在"""
        if not os.path.exists(self.archive_path):
            os.makedirs(self.archive_path)
    
    def _load(self) -> List[Dict]:
        """加载记忆"""
        if os.path.exists(self.storage_path):
            try:
                with open(self.storage_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    if isinstance(data, list):
                        return data
                    elif isinstance(data, dict) and "memories" in data:
                        return data["memories"]
            except (json.JSONDecodeError, IOError) as e:
                if self.config["debug"]:
                    safe_print(f"[WARN] 加载记忆失败: {e}")
                return []
        return []
    
    def _save(self):
        """保存记忆"""
        try:
            data = {
                "version": "2.0",
                "updated_at": datetime.now().isoformat(),
                "total_memories": len(self.memories),
                "memories": self.memories
            }
            with open(self.storage_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except IOError as e:
            safe_print(f"[ERROR] 保存记忆失败: {e}")
    
    def add_memory(
        self, 
        content: str, 
        layer: int = 1,
        tags: List[str] = None,
        link_to: List[str] = None,
        metadata: Dict[str, Any] = None,
        importance: int = 0,
        emotion: str = None
    ) -> str:
        """
        添加记忆
        
        Args:
            content: 记忆内容
            layer: 记忆层级 (1-6)
            tags: 标签列表
            link_to: 关联的记忆ID列表
            metadata: 元数据
            importance: 重要性 (0-10)
            emotion: 情绪标签 (happy/sad/angry/neutral)
        
        Returns:
            记忆ID
        """
        # 验证层级
        layer = max(1, min(6, layer))
        
        # 生成唯一ID
        memory_id = f"{datetime.now().strftime('%Y%m%d%H%M%S')}_{len(self.memories):04d}"
        
        # 自动提取标签
        auto_tags = self._extract_tags(content)
        all_tags = list(set((tags or []) + auto_tags))
        
        # 自动检测情绪
        if not emotion:
            emotion = self._detect_emotion(content)
        
        memory = {
            "id": memory_id,
            "content": content,
            "layer": layer,
            "layer_name": self.LAYERS.get(layer, "未知"),
            "tags": all_tags,
            "links": link_to or [],
            "metadata": metadata or {},
            "importance": importance,
            "emotion": emotion,
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat(),
            "accessed_count": 0,
            "last_accessed": None
        }
        
        self.memories.append(memory)
        self._save()
        
        # 自动触发关联
        self._auto_link(memory_id, content, all_tags)
        
        # 检查是否需要归档
        self._check_archive()
        
        return memory_id
    
    def _extract_tags(self, content: str) -> List[str]:
        """自动提取标签"""
        tags = []
        
        # 提取 #标签
        hash_tags = re.findall(r'#(\w+)', content)
        tags.extend(hash_tags)
        
        # 关键词提取（简单实现）
        keywords = {
            "用户": "人物:用户",
            "我": "人物:AI助手",
            "记忆": "话题:记忆",
            "技能": "话题:技能",
            "项目": "类型:项目",
            "学习": "话题:学习",
            "工作": "场景:工作",
            "生活": "场景:生活"
        }
        
        for keyword, tag in keywords.items():
            if keyword in content:
                tags.append(tag)
        
        return tags
    
    def _detect_emotion(self, content: str) -> str:
        """检测情绪"""
        emotion_keywords = {
            "happy": ["开心", "高兴", "喜欢", "爱", "棒", "帅", "好", "赞", "谢谢", "感谢", "哈哈", "嘻嘻"],
            "sad": ["难过", "伤心", "失望", "遗憾", "可惜"],
            "angry": ["生气", "火大", "烦", "讨厌", "不爽"],
            "fear": ["害怕", "担心", "恐惧", "紧张"],
            "surprise": ["意外", "震惊", "没想到", "居然"]
        }
        
        for emotion, keywords in emotion_keywords.items():
            for kw in keywords:
                if kw in content:
                    return emotion
        
        return "neutral"
    
    def _auto_link(self, memory_id: str, content: str, tags: List[str]):
        """自动关联相关记忆"""
        memory = self.get(memory_id, increment_access=False)
        if not memory:
            return
        
        new_links = []
        for m in self.memories:
            if m["id"] == memory_id:
                continue
            
            # 计算关联度
            common_tags = set(m["tags"]) & set(tags)
            link_score = len(common_tags)
            
            # 内容相似度（简单实现）
            if m["content"][:20] in content or content[:20] in m["content"]:
                link_score += 1
            
            # 超过阈值则建立链接
            if link_score >= self.config["link_threshold"]:
                if m["id"] not in memory.get("links", []):
                    new_links.append(m["id"])
                if memory_id not in m["links"]:
                    m["links"].append(memory_id)
        
        if new_links:
            memory["links"] = list(set(memory.get("links", []) + new_links))
        
        self._save()
    
    def get(self, memory_id: str, increment_access: bool = True) -> Optional[Dict]:
        """获取单条记忆"""
        for m in self.memories:
            if m["id"] == memory_id:
                if increment_access:
                    m["accessed_count"] += 1
                    m["last_accessed"] = datetime.now().isoformat()
                    self._save()
                return m
        return None
    
    def update(self, memory_id: str, **kwargs) -> bool:
        """更新记忆"""
        memory = self.get(memory_id, increment_access=False)
        if not memory:
            return False
        
        # 可更新的字段
        updatable = ["content", "layer", "tags", "importance", "metadata", "emotion"]
        for key, value in kwargs.items():
            if key in updatable:
                memory[key] = value
        
        memory["updated_at"] = datetime.now().isoformat()
        self._save()
        return True
    
    def delete(self, memory_id: str) -> bool:
        """删除记忆"""
        for i, m in enumerate(self.memories):
            if m["id"] == memory_id:
                # 从其他记忆的links中移除
                for other in self.memories:
                    if memory_id in other.get("links", []):
                        other["links"].remove(memory_id)
                
                del self.memories[i]
                self._save()
                return True
        return False
    
    def search(
        self, 
        query: str, 
        layer_filter: List[int] = None,
        tags: List[str] = None,
        emotion: str = None,
        min_importance: int = 0,
        days: int = None,
        limit: int = 10
    ) -> List[Dict]:
        """
        多维度检索记忆
        
        Args:
            query: 搜索关键词
            layer_filter: 层级过滤
            tags: 标签过滤
            emotion: 情绪过滤
            min_importance: 最小重要性
            days: 最近N天
            limit: 返回数量限制
        """
        results = []
        cutoff = datetime.now() - timedelta(days=days) if days else None
        
        for m in self.memories:
            # 层级过滤
            if layer_filter and m["layer"] not in layer_filter:
                continue
            
            # 标签过滤
            if tags:
                if not any(t in m["tags"] for t in tags):
                    continue
            
            # 情绪过滤
            if emotion and m.get("emotion") != emotion:
                continue
            
            # 重要性过滤
            if m.get("importance", 0) < min_importance:
                continue
            
            # 时间过滤
            if cutoff:
                try:
                    created = datetime.fromisoformat(m["created_at"])
                    if created < cutoff:
                        continue
                except:
                    pass
            
            # 计算相关性得分
            score = self._calculate_relevance(m, query)
            
            if score > 0:
                results.append((score, m))
        
        # 按得分排序
        results.sort(key=lambda x: x[0], reverse=True)
        return [r[1] for r in results[:limit]]
    
    def _calculate_relevance(self, memory: Dict, query: str) -> float:
        """计算相关性得分"""
        score = 0.0
        
        # 内容匹配
        content = memory["content"].lower()
        query_lower = query.lower()
        
        if query_lower in content:
            score += 10.0
            # 完全匹配加分
            if content.startswith(query_lower) or content.endswith(query_lower):
                score += 5.0
        
        # 标签匹配
        for tag in memory.get("tags", []):
            if query_lower in tag.lower():
                score += 3.0
        
        # 访问频率加权
        score += memory.get("accessed_count", 0) * 0.1
        
        # 重要性加权
        score += memory.get("importance", 0) * 0.5
        
        return score
    
    def summarize(
        self, 
        days: int = 7,
        layer: int = None
    ) -> Dict[str, Any]:
        """生成摘要"""
        cutoff = datetime.now() - timedelta(days=days)
        recent = []
        
        for m in self.memories:
            try:
                created = datetime.fromisoformat(m["created_at"])
                if created >= cutoff:
                    if layer is None or m["layer"] == layer:
                        recent.append(m)
            except:
                continue
        
        # 按层级统计
        by_layer = {}
        for m in recent:
            layer_name = m["layer_name"]
            if layer_name not in by_layer:
                by_layer[layer_name] = []
            by_layer[layer_name].append(m)
        
        # 情绪统计
        emotions = Counter(m.get("emotion", "neutral") for m in recent)
        
        # 提取关键词
        all_tags = []
        for m in recent:
            all_tags.extend(m.get("tags", []))
        top_tags = Counter(all_tags).most_common(20)
        
        # 高重要性记忆
        important = [m for m in recent if m.get("importance", 0) >= 5]
        
        return {
            "period_days": days,
            "total_memories": len(recent),
            "by_layer": {k: len(v) for k, v in by_layer.items()},
            "emotions": dict(emotions),
            "top_tags": top_tags,
            "important_memories": len(important),
            "memories": recent
        }
    
    def archive_chat(self, messages: List[Dict], source: str = "unknown") -> str:
        """
        对话归档 - 自动提取关键信息
        
        Args:
            messages: 消息列表 [{"content": "...", "role": "user/assistant"}]
            source: 来源标识
        
        Returns:
            记忆ID
        """
        if not messages:
            return None
        
        # 提取关键信息
        all_text = " ".join([m.get("content", "") for m in messages])
        
        # 提取标签
        tags = self._extract_tags(all_text)
        
        # 检测情绪
        emotion = self._detect_emotion(all_text)
        
        # 统计
        user_count = len([m for m in messages if m.get("role") == "user"])
        assistant_count = len([m for m in messages if m.get("role") == "assistant"])
        
        # 生成摘要
        summary = f"对话归档[{source}]: {len(messages)}条消息 ({user_count}用户/{assistant_count}助手)"
        
        # 自动判断层级
        if emotion != "neutral":
            layer = 2  # 情绪记忆
        elif len(messages) > 10:
            layer = 3  # 场景记忆
        else:
            layer = 1  # 初始记忆
        
        # 创建记忆
        memory_id = self.add_memory(
            content=summary,
            layer=layer,
            tags=tags + ["对话归档", source],
            metadata={
                "source": source,
                "message_count": len(messages),
                "user_count": user_count,
                "assistant_count": assistant_count
            },
            emotion=emotion
        )
        
        return memory_id
    
    def _check_archive(self):
        """检查是否需要归档旧记忆"""
        if len(self.memories) > self.config["max_memories"]:
            self._archive_old_memories()
    
    def _archive_old_memories(self):
        """归档旧记忆"""
        cutoff = datetime.now() - timedelta(days=self.config["auto_archive_days"])
        
        to_archive = []
        to_keep = []
        
        for m in self.memories:
            try:
                created = datetime.fromisoformat(m["created_at"])
                # 高重要性的保留
                if created < cutoff and m.get("importance", 0) < self.config["importance_threshold"]:
                    to_archive.append(m)
                else:
                    to_keep.append(m)
            except:
                to_keep.append(m)
        
        if to_archive:
            # 保存归档文件
            archive_file = os.path.join(
                self.archive_path, 
                f"archive_{datetime.now().strftime('%Y%m%d')}.json"
            )
            
            with open(archive_file, 'w', encoding='utf-8') as f:
                json.dump({
                    "archived_at": datetime.now().isoformat(),
                    "count": len(to_archive),
                    "memories": to_archive
                }, f, ensure_ascii=False, indent=2)
            
            self.memories = to_keep
            self._save()
            
            if self.config["debug"]:
                safe_print(f"[INFO] 已归档 {len(to_archive)} 条旧记忆")
    
    def get_layer_stats(self) -> Dict[int, Dict]:
        """获取各层级详细统计"""
        stats = {}
        for i in range(1, 7):
            layer_memories = [m for m in self.memories if m["layer"] == i]
            stats[i] = {
                "name": self.LAYERS[i],
                "count": len(layer_memories),
                "avg_importance": sum(m.get("importance", 0) for m in layer_memories) / max(len(layer_memories), 1),
                "total_accesses": sum(m.get("accessed_count", 0) for m in layer_memories)
            }
        return stats
    
    def export(self, output_path: str = None, format: str = "json"):
        """导出记忆"""
        output_path = output_path or f"./memory_export_{datetime.now().strftime('%Y%m%d')}.{format}"
        
        if format == "json":
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(self.memories, f, ensure_ascii=False, indent=2)
        elif format == "markdown":
            lines = ["# Memory Chain Export\n"]
            for m in self.memories:
                lines.append(f"## [{m['layer_name']}] {m['id']}\n")
                lines.append(f"{m['content']}\n")
                lines.append(f"- 标签: {', '.join(m['tags'])}\n")
                lines.append(f"- 创建: {m['created_at']}\n")
                lines.append(f"- 访问: {m['accessed_count']}次\n\n")
            
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write("".join(lines))
        
        return output_path
    
    def merge_duplicates(self) -> int:
        """合并重复记忆"""
        seen = {}
        duplicates = []
        
        for m in self.memories:
            content_key = m["content"][:50]  # 用前50字符作为key
            if content_key in seen:
                # 合并标签和链接
                seen[content_key]["tags"] = list(set(seen[content_key]["tags"] + m["tags"]))
                seen[content_key]["links"] = list(set(seen[content_key]["links"] + m["links"]))
                seen[content_key]["accessed_count"] += m["accessed_count"]
                duplicates.append(m["id"])
            else:
                seen[content_key] = m
        
        # 移除重复
        self.memories = [m for m in self.memories if m["id"] not in duplicates]
        self._save()
        
        return len(duplicates)


if __name__ == "__main__":
    # 测试
    mc = MemoryChain()
    
    # 添加示例记忆
    mc.add_memory(
        content="用户喜欢使用AI助手处理日常任务",
        layer=2,
        tags=["preference", "AI"],
        importance=8
    )
    
    mc.add_memory(
        content="AI助手是用户的智能伙伴，帮助记忆和管理信息",
        layer=5,
        tags=["identity", "AI"],
        importance=9
    )
    
    mc.add_memory(
        content="今天完成了Memory Chain技能的开发和测试",
        layer=3,
        tags=["project", "skill", "development"],
        emotion="happy"
    )
    
    safe_print("\n[Stats] 记忆统计:")
    stats = mc.get_layer_stats()
    for layer, info in stats.items():
        safe_print(f"  L{layer} {info['name']}: {info['count']}条")
    
    safe_print("\n[Search] 搜索'AI':")
    results = mc.search("AI")
    for r in results:
        safe_print(f"  [{r['layer_name']}] {r['content'][:30]}...")
