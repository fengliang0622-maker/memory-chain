#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Memory Chain CLI - 命令行工具 (增强版)
"""

import argparse
import json
import sys
from pathlib import Path
from datetime import datetime

# 添加脚本目录到路径
sys.path.insert(0, str(Path(__file__).parent))

from memory_chain import MemoryChain

# 安全打印
def safe_print(text: str):
    """安全打印，兼容GBK编码"""
    try:
        print(text)
    except UnicodeEncodeError:
        replacements = {
            '✅': '[OK]', '❌': '[X]', '🔍': '[Search]', '📊': '[Stats]',
            '📝': '[Note]', '🔗': '[Link]', '🧠': '[Brain]', '💾': '[Save]',
            '⚡': '[!]', '🎯': '[Target]', '📈': '[Up]', '🗑️': '[Del]',
            '📦': '[Box]', '🔧': '[Tool]', '💾': '[Save]',
        }
        for emoji, ascii_alt in replacements.items():
            text = text.replace(emoji, ascii_alt)
        print(text)


def cmd_add(args, mc: MemoryChain):
    """添加记忆"""
    memory_id = mc.add_memory(
        content=args.content,
        layer=args.layer,
        tags=args.tags,
        importance=args.importance,
        emotion=args.emotion
    )
    layer_name = MemoryChain.LAYERS.get(args.layer, "未知")
    safe_print(f"[OK] 记忆已添加: {memory_id}")
    safe_print(f"    层级: L{args.layer} {layer_name}")
    if args.tags:
        safe_print(f"    标签: {', '.join(args.tags)}")


def cmd_search(args, mc: MemoryChain):
    """搜索记忆"""
    layer_filter = args.layer if args.layer else None
    
    results = mc.search(
        query=args.query,
        layer_filter=layer_filter,
        tags=args.tags,
        emotion=args.emotion,
        min_importance=args.min_importance,
        days=args.days,
        limit=args.limit
    )
    
    safe_print(f"\n[Search] 找到 {len(results)} 条记忆:")
    safe_print("-" * 60)
    
    for i, r in enumerate(results, 1):
        safe_print(f"\n{i}. [{r['layer_name']}] {r['id']}")
        safe_print(f"   内容: {r['content'][:80]}{'...' if len(r['content']) > 80 else ''}")
        safe_print(f"   标签: {', '.join(r['tags'][:5])}")
        safe_print(f"   访问: {r['accessed_count']}次 | 重要: {r.get('importance', 0)}")
        if r.get('emotion') and r['emotion'] != 'neutral':
            safe_print(f"   情绪: {r['emotion']}")


def cmd_stats(args, mc: MemoryChain):
    """查看统计"""
    stats = mc.get_layer_stats()
    total = sum(s['count'] for s in stats.values())
    
    safe_print("\n[Stats] 记忆统计:")
    safe_print("=" * 50)
    safe_print(f"总记忆数: {total}")
    safe_print("-" * 50)
    
    for layer, info in stats.items():
        bar = "=" * min(info['count'], 20)
        safe_print(f"L{layer} {info['name']:8} | {bar} {info['count']}")
        if args.verbose:
            safe_print(f"     平均重要性: {info['avg_importance']:.1f}")
            safe_print(f"     总访问次数: {info['total_accesses']}")


def cmd_summarize(args, mc: MemoryChain):
    """生成摘要"""
    summary = mc.summarize(days=args.days, layer=args.layer)
    
    safe_print(f"\n[Summary] {args.days}天摘要:")
    safe_print("=" * 50)
    safe_print(f"总记忆数: {summary['total_memories']}")
    safe_print(f"高重要性: {summary['important_memories']}")
    safe_print("-" * 50)
    
    safe_print("\n按层级:")
    for layer, count in summary['by_layer'].items():
        safe_print(f"  {layer}: {count}条")
    
    if summary['emotions']:
        safe_print("\n情绪分布:")
        for emotion, count in summary['emotions'].items():
            safe_print(f"  {emotion}: {count}条")
    
    if summary['top_tags']:
        safe_print("\n热门标签:")
        for tag, count in summary['top_tags'][:10]:
            safe_print(f"  #{tag}: {count}次")


def cmd_get(args, mc: MemoryChain):
    """获取单条记忆"""
    memory = mc.get(args.id)
    
    if not memory:
        safe_print(f"[X] 未找到记忆: {args.id}")
        return
    
    safe_print(f"\n[Memory] {memory['id']}:")
    safe_print("=" * 50)
    safe_print(f"层级: L{memory['layer']} {memory['layer_name']}")
    safe_print(f"内容: {memory['content']}")
    safe_print(f"标签: {', '.join(memory['tags'])}")
    safe_print(f"情绪: {memory.get('emotion', 'neutral')}")
    safe_print(f"重要性: {memory.get('importance', 0)}")
    safe_print(f"访问次数: {memory['accessed_count']}")
    safe_print(f"创建时间: {memory['created_at']}")
    safe_print(f"更新时间: {memory.get('updated_at', 'N/A')}")
    
    if memory.get('links'):
        safe_print(f"关联: {len(memory['links'])}条")
    
    if memory.get('metadata'):
        safe_print(f"元数据: {json.dumps(memory['metadata'], ensure_ascii=False)}")


def cmd_update(args, mc: MemoryChain):
    """更新记忆"""
    updates = {}
    if args.content:
        updates['content'] = args.content
    if args.layer:
        updates['layer'] = args.layer
    if args.importance is not None:
        updates['importance'] = args.importance
    if args.tags:
        updates['tags'] = args.tags
    
    if mc.update(args.id, **updates):
        safe_print(f"[OK] 记忆已更新: {args.id}")
    else:
        safe_print(f"[X] 更新失败: {args.id}")


def cmd_delete(args, mc: MemoryChain):
    """删除记忆"""
    if mc.delete(args.id):
        safe_print(f"[OK] 记忆已删除: {args.id}")
    else:
        safe_print(f"[X] 删除失败: {args.id}")


def cmd_export(args, mc: MemoryChain):
    """导出记忆"""
    output_path = mc.export(output_path=args.output, format=args.format)
    safe_print(f"[OK] 已导出到: {output_path}")


def cmd_merge(args, mc: MemoryChain):
    """合并重复记忆"""
    count = mc.merge_duplicates()
    safe_print(f"[OK] 已合并 {count} 条重复记忆")


def cmd_archive(args, mc: MemoryChain):
    """归档对话"""
    # 从文件读取或stdin
    if args.file:
        with open(args.file, 'r', encoding='utf-8') as f:
            messages = json.load(f)
    elif not sys.stdin.isatty():
        messages = json.load(sys.stdin)
    else:
        safe_print("[X] 请提供消息文件或通过stdin传入")
        return
    
    memory_id = mc.archive_chat(messages, source=args.source)
    if memory_id:
        safe_print(f"[OK] 对话已归档: {memory_id}")
    else:
        safe_print("[X] 归档失败")


def main():
    parser = argparse.ArgumentParser(
        description="Memory Chain CLI - 六层记忆架构命令行工具",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument("--storage", "-s", help="存储文件路径")
    
    subparsers = parser.add_subparsers(dest="command", help="命令")
    
    # add 命令
    add_parser = subparsers.add_parser("add", help="添加记忆")
    add_parser.add_argument("content", help="记忆内容")
    add_parser.add_argument("-l", "--layer", type=int, default=1, help="记忆层级(1-6)")
    add_parser.add_argument("-t", "--tags", nargs="+", help="标签")
    add_parser.add_argument("-i", "--importance", type=int, default=0, help="重要性(0-10)")
    add_parser.add_argument("-e", "--emotion", help="情绪(happy/sad/angry/neutral)")
    
    # search 命令
    search_parser = subparsers.add_parser("search", help="搜索记忆")
    search_parser.add_argument("query", help="搜索关键词")
    search_parser.add_argument("-l", "--layer", type=int, nargs="+", help="层级过滤")
    search_parser.add_argument("-t", "--tags", nargs="+", help="标签过滤")
    search_parser.add_argument("-e", "--emotion", help="情绪过滤")
    search_parser.add_argument("--min-importance", type=int, default=0, help="最小重要性")
    search_parser.add_argument("-d", "--days", type=int, help="最近N天")
    search_parser.add_argument("--limit", type=int, default=10, help="返回数量")
    
    # stats 命令
    stats_parser = subparsers.add_parser("stats", help="查看统计")
    stats_parser.add_argument("-v", "--verbose", action="store_true", help="详细输出")
    
    # summarize 命令
    sum_parser = subparsers.add_parser("summarize", help="生成摘要")
    sum_parser.add_argument("-d", "--days", type=int, default=7, help="天数")
    sum_parser.add_argument("-l", "--layer", type=int, help="层级过滤")
    
    # get 命令
    get_parser = subparsers.add_parser("get", help="获取单条记忆")
    get_parser.add_argument("id", help="记忆ID")
    
    # update 命令
    update_parser = subparsers.add_parser("update", help="更新记忆")
    update_parser.add_argument("id", help="记忆ID")
    update_parser.add_argument("-c", "--content", help="新内容")
    update_parser.add_argument("-l", "--layer", type=int, help="新层级")
    update_parser.add_argument("-i", "--importance", type=int, help="新重要性")
    update_parser.add_argument("-t", "--tags", nargs="+", help="新标签")
    
    # delete 命令
    delete_parser = subparsers.add_parser("delete", help="删除记忆")
    delete_parser.add_argument("id", help="记忆ID")
    
    # export 命令
    export_parser = subparsers.add_parser("export", help="导出记忆")
    export_parser.add_argument("-o", "--output", help="输出文件")
    export_parser.add_argument("-f", "--format", choices=["json", "markdown"], default="json")
    
    # merge 命令
    subparsers.add_parser("merge", help="合并重复记忆")
    
    # archive 命令
    archive_parser = subparsers.add_parser("archive", help="归档对话")
    archive_parser.add_argument("-f", "--file", help="消息文件(JSON)")
    archive_parser.add_argument("-s", "--source", default="cli", help="来源标识")
    
    args = parser.parse_args()
    
    # 初始化
    mc = MemoryChain(storage_path=args.storage)
    
    # 分发命令
    if args.command == "add":
        cmd_add(args, mc)
    elif args.command == "search":
        cmd_search(args, mc)
    elif args.command == "stats":
        cmd_stats(args, mc)
    elif args.command == "summarize":
        cmd_summarize(args, mc)
    elif args.command == "get":
        cmd_get(args, mc)
    elif args.command == "update":
        cmd_update(args, mc)
    elif args.command == "delete":
        cmd_delete(args, mc)
    elif args.command == "export":
        cmd_export(args, mc)
    elif args.command == "merge":
        cmd_merge(args, mc)
    elif args.command == "archive":
        cmd_archive(args, mc)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
