#!/usr/bin/env python3
"""
Chat归档器 - 自动从对话中提取关键信息并归档

用法：
    python chat_archiver.py --session "对话内容..." --source wechat
    python chat_archiver.py --session-file session.txt --source telegram
    python chat_archiver.py --today --source webchat
"""

import re
import os
import json
import argparse
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Optional

# 配置
CHAT_ARCHIVE_DIR = Path("memory/chats")

# 提取规则
EXTRACTION_RULES = {
    "决策": {
        "keywords": ["决定", "选择", "确定", "就这个", "用这个", "好了", "开始", "不再"],
        "priority": "high"
    },
    "偏好": {
        "keywords": ["喜欢", "不喜欢", "偏好", "想要", "不要", "爱", "讨厌"],
        "priority": "medium"
    },
    "待办": {
        "keywords": ["要做", "帮我", "完成", "记得", "要研究", "要看看", "去", "做一下"],
        "priority": "high"
    },
    "经验": {
        "keywords": ["学会", "发现", "总结", "教训", "踩坑", "翻车", "成功了", "失败了"],
        "priority": "medium"
    },
    "项目": {
        "keywords": ["项目", "功能", "开发", "实现", "发布", "上线", "版本"],
        "priority": "medium"
    },
    "人物": {
        "keywords": ["用户", "谁", "他", "她", "他们", "大家"],
        "priority": "low"
    }
}

# 来源映射
SOURCE_EMOJI = {
    "telegram": "💬",
    "wechat": "💬",
    "whatsapp": "💬",
    "discord": "🎮",
    "webchat": "🌐",
    "signal": "🔒",
    "default": "💭"
}

def extract_key_info(messages: List[str]) -> Dict:
    """从对话消息中提取关键信息"""
    extracted = {
        "决策": [],
        "偏好": [],
        "待办": [],
        "经验": [],
        "项目": [],
        "人物": []
    }
    
    for msg in messages:
        msg_lower = msg.lower()
        
        # 检测决策
        if any(kw in msg_lower for kw in EXTRACTION_RULES["决策"]["keywords"]):
            if "?" not in msg and len(msg) > 5:  # 过滤提问
                extracted["决策"].append(msg.strip())
        
        # 检测偏好
        if any(kw in msg_lower for kw in EXTRACTION_RULES["偏好"]["keywords"]):
            extracted["偏好"].append(msg.strip())
        
        # 检测待办
        if any(kw in msg_lower for kw in EXTRACTION_RULES["待办"]["keywords"]):
            extracted["待办"].append(msg.strip())
        
        # 检测经验
        if any(kw in msg_lower for kw in EXTRACTION_RULES["经验"]["keywords"]):
            extracted["经验"].append(msg.strip())
        
        # 检测项目
        if any(kw in msg_lower for kw in EXTRACTION_RULES["项目"]["keywords"]):
            extracted["项目"].append(msg.strip())
        
        # 检测人物
        if any(kw in msg_lower for kw in EXTRACTION_RULES["人物"]["keywords"]):
            extracted["人物"].append(msg.strip())
    
    return extracted

def generate_tags(extracted: Dict) -> List[str]:
    """根据提取的信息生成标签"""
    tags = []
    
    if extracted["决策"]:
        tags.append("#重要")
    if extracted["待办"]:
        tags.append("#待办")
    if extracted["经验"]:
        tags.append("#经验")
    if extracted["项目"]:
        tags.append("#项目")
    if extracted["人物"]:
        tags.append("#人物")
    if extracted["偏好"]:
        tags.append("#人物")
    
    return list(set(tags))

def parse_messages(content: str) -> List[str]:
    """解析对话内容，提取消息列表"""
    messages = []
    
    # 尝试多种格式
    # 格式1: 时间 - 说话者: 内容
    pattern1 = r'\[?(\d{1,2}:\d{2})\]?\s*[-–]?\s*([^:]+):\s*(.+)'
    # 格式2: 说话者: 内容
    pattern2 = r'^([^:]+):\s*(.+)$'
    # 格式3: 时间 内容
    pattern3 = r'\[?(\d{1,2}:\d{2})\]?\s*(.+)'
    
    for line in content.split('\n'):
        line = line.strip()
        if not line:
            continue
        
        # 尝试匹配各种格式
        match1 = re.match(pattern1, line)
        match2 = re.match(pattern2, line)
        match3 = re.match(pattern3, line)
        
        if match1:
            messages.append(match1.group(3))
        elif match2:
            messages.append(match2.group(2))
        elif match3:
            messages.append(match3.group(2))
        else:
            # 未识别的行，可能是连续内容
            if messages:
                messages[-1] += " " + line
    
    return messages

def generate_archive_entry(
    messages: List[str],
    source: str,
    topic: str = None,
    participants: List[str] = None
) -> str:
    """生成归档条目"""
    now = datetime.now()
    date_str = now.strftime("%Y-%m-%d")
    time_str = now.strftime("%H:%M")
    
    # 提取关键信息
    extracted = extract_key_info(messages)
    tags = generate_tags(extracted)
    
    # 确定主题
    if not topic:
        # 尝试从消息中提取主题
        for msg in messages[:3]:
            if any(kw in msg.lower() for kw in ["关于", "讨论", "说"]):
                topic = "综合对话"
                break
        topic = topic or "综合对话"
    
    # 构建输出
    emoji = SOURCE_EMOJI.get(source.lower(), SOURCE_EMOJI["default"])
    
    lines = [
        f"## [{emoji} 来源: {source}] {topic}",
        "",
        f"**日期**: {date_str}",
        f"**时间**: {time_str}",
        f"**消息数**: {len(messages)}",
    ]
    
    if participants:
        lines.append(f"**参与者**: {', '.join(participants)}")
    
    lines.append("")
    
    # 关键信息摘要
    if any(extracted.values()):
        lines.append("### 关键信息")
        
        if extracted["决策"]:
            lines.append("📌 **决策**:")
            for d in extracted["决策"][:3]:
                lines.append(f"   - {d[:80]}{'...' if len(d) > 80 else ''}")
        
        if extracted["偏好"]:
            lines.append("💡 **偏好**:")
            for p in extracted["偏好"][:3]:
                lines.append(f"   - {p[:80]}{'...' if len(p) > 80 else ''}")
        
        if extracted["待办"]:
            lines.append("📝 **待办**:")
            for t in extracted["待办"][:3]:
                lines.append(f"   - {t[:80]}{'...' if len(t) > 80 else ''}")
        
        if extracted["经验"]:
            lines.append("💎 **经验**:")
            for e in extracted["经验"][:3]:
                lines.append(f"   - {e[:80]}{'...' if len(e) > 80 else ''}")
        
        lines.append("")
    
    # 对话片段（采样）
    if messages:
        lines.append("### 对话片段")
        # 取前5条和后3条
        sample = messages[:5]
        if len(messages) > 8:
            sample.append("...")
            sample.extend(messages[-3:])
        
        for msg in sample:
            if len(msg) > 100:
                msg = msg[:100] + "..."
            lines.append(f"> {msg}")
        
        lines.append("")
    
    # 标签和关联
    lines.append(f"> 🏷️ 标签：{' '.join(tags)}")
    lines.append(f"> 🔗 关联：[memory/{date_str}.md]")
    lines.append("")
    
    return "\n".join(lines)

def save_archive(entry: str, source: str) -> Path:
    """保存归档到文件"""
    now = datetime.now()
    date_str = now.strftime("%Y-%m-%d")
    
    # 创建目录
    archive_dir = CHAT_ARCHIVE_DIR
    archive_dir.mkdir(parents=True, exist_ok=True)
    
    # 文件名
    file_path = archive_dir / f"{date_str}.md"
    
    # 如果文件已存在，追加
    if file_path.exists():
        existing = file_path.read_text(encoding='utf-8')
        # 检查是否已包含这个条目（简单去重）
        if entry[:50] in existing:
            print(f"⚠️ 今日已归档类似内容，跳过")
            return file_path
        
        content = existing + "\n\n---\n\n" + entry
    else:
        content = f"# Chat归档 - {date_str}\n\n" + entry
    
    file_path.write_text(content, encoding='utf-8')
    return file_path

def archive_session(
    session_content: str,
    source: str,
    topic: str = None,
    participants: List[str] = None,
    dry_run: bool = False
) -> Dict:
    """归档一个会话"""
    # 解析消息
    messages = parse_messages(session_content)
    
    if not messages:
        print("⚠️ 未解析到有效消息")
        return {}
    
    print(f"📊 解析到 {len(messages)} 条消息")
    
    # 提取关键信息
    extracted = extract_key_info(messages)
    print(f"📌 决策: {len(extracted['决策'])} | 待办: {len(extracted['待办'])} | 经验: {len(extracted['经验'])}")
    
    # 生成归档
    entry = generate_archive_entry(messages, source, topic, participants)
    
    if dry_run:
        print("\n🔍 预览模式（未保存）:")
        print(entry[:500] + "...")
        return {"preview": entry, "messages": len(messages)}
    
    # 保存
    file_path = save_archive(entry, source)
    print(f"✅ 已归档到: {file_path}")
    
    return {
        "file": str(file_path),
        "messages": len(messages),
        "extracted": {k: len(v) for k, v in extracted.items()}
    }

def main():
    parser = argparse.ArgumentParser(description='Chat归档器')
    parser.add_argument('--session', '-s', help='对话内容（直接传入）')
    parser.add_argument('--session-file', '-f', help='对话文件路径')
    parser.add_argument('--source', '-src', default='webchat', 
                       help='来源: wechat/telegram/discord/webchat等')
    parser.add_argument('--topic', '-t', help='对话主题')
    parser.add_argument('--participants', '-p', nargs='*', help='参与者')
    parser.add_argument('--today', action='store_true', help='使用今日对话（需配置）')
    parser.add_argument('--dry-run', '-d', action='store_true', help='预览模式')
    
    args = parser.parse_args()
    
    if args.session:
        content = args.session
    elif args.session_file:
        content = Path(args.session_file).read_text(encoding='utf-8')
    elif args.today:
        # 从当前会话获取
        print("📋 请输入或粘贴对话内容（输入完成请按Ctrl+D或空行结束）:")
        content = sys.stdin.read()
    else:
        parser.print_help()
        sys.exit(1)
    
    result = archive_session(
        content,
        source=args.source,
        topic=args.topic,
        participants=args.participants,
        dry_run=args.dry_run
    )
    
    if result:
        print(f"\n📈 统计: {result.get('messages', 0)} 条消息")

if __name__ == "__main__":
    import sys
    main()
