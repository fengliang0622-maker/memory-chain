#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
记忆分类器 - 自动为记忆文件生成分类标签

用法：
    python memory_classifier.py --file memory/2026-03-16.md
    python memory_classifier.py --file memory/2026-03-16.md --dry-run
"""

import re
import sys
import argparse
from datetime import datetime
from pathlib import Path

# 分类关键词映射
CLASSIFICATION_KEYWORDS = {
    "#重要": ["决策", "决定", "选择", "偏好", "喜欢", "不喜欢", "原则", "规则", "限制", "目标", "承诺"],
    "#待办": ["需要", "将要做", "计划", "应该做", "必须做", "截止", "期限", "deadline", "跟进", "后续", "检查", "完成"],
    "#经验": ["学会", "发现", "总结", "教训", "踩坑", "翻车", "改进", "优化", "调整", "成功", "失败", "尝试"],
    "#灵感": ["想法", "创意", "构思", "突然想到", "闪过", "也许", "可以尝试", "有趣", "值得关注"],
    "#人物": ["用户", "说", "告诉", "提到", "互动", "关系"],
    "#项目": ["项目", "任务", "功能", "开发", "实现", "完成", "问题", "bug", "修复", "发布", "上线", "版本"],
    "#技术": ["代码", "API", "脚本", "工具", "平台", "系统", "编程", "开发"],
    "#生活": ["日常", "习惯", "日程", "安排", "生活"],
}

def classify_content(content: str) -> list:
    """根据内容返回分类标签列表"""
    tags = set()
    content_lower = content.lower()
    
    for tag, keywords in CLASSIFICATION_KEYWORDS.items():
        for keyword in keywords:
            if keyword.lower() in content_lower:
                tags.add(tag)
                break
    
    return sorted(list(tags))

def determine_importance(content: str) -> str:
    """根据内容确定重要程度"""
    importance_markers = {
        "[!!!]": ["重要决策", "关键", "必须", "核心", "永远不要"],
        "[!!]": ["重要", "应该", "需要", "承诺"],
        "[!]": ["一般", "可能", "考虑"],
    }
    
    content_lower = content.lower()
    for level, markers in importance_markers.items():
        for marker in markers:
            if marker in content_lower:
                return level
    
    return "[ ]"  # 默认临时标记

def process_memory_file(file_path: Path, dry_run: bool = False) -> dict:
    """处理记忆文件，添加分类标签"""
    
    if not file_path.exists():
        print(f"[ERROR] File not found: {file_path}")
        return {}
    
    content = file_path.read_text(encoding='utf-8')
    
    # 分析每个记忆条目（假设以 ## 开头）
    pattern = r'##\s*(\[[^\]]+\])?\s*([^\n]+)\n([^#]+)'
    matches = re.findall(pattern, content, re.DOTALL)
    
    results = []
    new_content = content
    
    for existing_tag, title, body in matches:
        full_text = f"{title}\n{body}"
        tags = classify_content(full_text)
        importance = determine_importance(full_text)
        
        # 构建新的标签行
        tag_section = f"\n> [TAGS] {' '.join(tags)} {importance}"
        
        # 检查是否已有标签行
        if "[TAGS]" not in body and "标签：" not in body:
            # 在条目末尾添加标签
            old_section = f"## {existing_tag or ''} {title}\n{body}"
            new_section = f"## [{', '.join(tags)}] {title}\n{body.rstrip()}\n{tag_section}\n"
            new_content = new_content.replace(old_section.strip(), new_section.strip())
        
        results.append({
            "title": title.strip(),
            "tags": tags,
            "importance": importance
        })
    
    if not dry_run:
        file_path.write_text(new_content, encoding='utf-8')
        print(f"[OK] Updated: {file_path}")
    else:
        print(f"[PREVIEW] Dry run (not saved): {file_path}")
    
    # 打印分类结果
    for r in results:
        title_preview = r['title'][:40] + "..." if len(r['title']) > 40 else r['title']
        print(f"  -> {title_preview}")
        print(f"     Tags: {' '.join(r['tags'])} {r['importance']}")
    
    return {
        "file": str(file_path),
        "entries": len(results),
        "classifications": results
    }

def main():
    parser = argparse.ArgumentParser(description='Memory Classifier')
    parser.add_argument('--file', '-f', required=True, help='Memory file path')
    parser.add_argument('--dry-run', '-d', action='store_true', help='Preview mode')
    
    args = parser.parse_args()
    
    file_path = Path(args.file)
    result = process_memory_file(file_path, dry_run=args.dry_run)
    
    if result:
        print(f"\n[DONE] Processed {result['entries']} memory entries")

if __name__ == "__main__":
    main()
