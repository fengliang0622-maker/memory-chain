#!/usr/bin/env python3
"""
自动归档当前会话到记忆链
"""

import sys
import os

# 添加父目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from memory_chain import MemoryChain
from datetime import datetime

def auto_archive_current_session(session_key: str = None, max_messages: int = 20):
    """
    自动归档当前会话
    
    Args:
        session_key: 会话key，如果为None则尝试从环境获取
        max_messages: 最多归档的消息数
    """
    mc = MemoryChain()
    
    messages = []
    
    # 方式1: 如果传入了session_key，尝试获取历史
    if session_key:
        try:
            from sessions_history import fetch_history
            # 这个需要通过OpenClaw API获取，暂时用模拟数据
        except:
            pass
    
    # 方式2: 尝试读取本地消息缓存（如果有的话）
    cache_path = "./chat_cache.json"
    if os.path.exists(cache_path):
        with open(cache_path, 'r', encoding='utf-8') as f:
            messages = json.load(f)
    
    if not messages:
        # 方式3: 从stdin读取JSON消息列表
        if not sys.stdin.isatty():
            try:
                messages = json.load(sys.stdin)
            except:
                pass
    
    if not messages:
        print("❌ 没有找到可归档的消息")
        print("用法1: python auto_archive.py --session <session_key>")
        print("用法2: python auto_archive.py --cache <json_file>")
        print("用法3: echo '[{\"content\": \"消息1\", \"role\": \"user\"}]' | python auto_archive.py")
        return
    
    # 提取关键信息
    user_messages = [m for m in messages if m.get("role") == "user"]
    assistant_messages = [m for m in messages if m.get("role") == "assistant"]
    
    # 提取所有文本内容
    all_text = " ".join([m.get("content", "") for m in messages])
    
    # 提取标签
    tags = re.findall(r'#(\w+)', all_text)
    
    # 提取关键词 (简单实现)
    keywords = []
    important_words = ["用户", "记忆", "任务", "项目", "创作", "发布", "学习"]
    for word in important_words:
        if word in all_text:
            keywords.append(word)
    
    # 自动判断层级
    if any(e in all_text for e in ["开心", "高兴", "喜欢", "爱", "棒", "帅"]):
        layer = 2  # 情绪记忆
    elif len(messages) > 5:
        layer = 3  # 场景记忆
    else:
        layer = 1  # 初始记忆
    
    # 添加记忆
    memory_id = mc.add_memory(
        content=f"对话归档: {len(messages)}条消息 ({len(user_messages)}用户/{len(assistant_messages)}助手)",
        layer=layer,
        tags=list(set(tags + keywords)),
        metadata={
            "message_count": len(messages),
            "user_count": len(user_messages),
            "assistant_count": len(assistant_messages),
            "archived_at": datetime.now().isoformat()
        }
    )
    
    print(f"✅ 已自动归档 {len(messages)} 条消息")
    print(f"   记忆ID: {memory_id}")
    print(f"   层级: L{layer}")
    print(f"   标签: {list(set(tags + keywords))}")
    
    return memory_id


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="自动归档会话")
    parser.add_argument("--session", help="会话key")
    parser.add_argument("--cache", help="本地缓存文件")
    parser.add_argument("--messages", type=int, default=20, help="最多消息数")
    
    args = parser.parse_args()
    
    if args.cache and os.path.exists(args.cache):
        with open(args.cache, 'r', encoding='utf-8') as f:
            messages = json.load(f)
        # 模拟调用
        sys.stdin = open(0)  # reset stdin
        os.environ["CHAT_CACHE"] = args.cache
    
    auto_archive_current_session(args.session, args.messages)
