#!/usr/bin/env python3
"""
记忆摘要生成器 - 为记忆文件生成结构化摘要

用法：
    python memory_summary.py --file memory/2026-03-16.md
    python memory_summary.py --file memory/2026-03-16.md --output summary.md
    python memory_summary.py --dir memory --output weekly.md
"""

import re
import sys
import argparse
from datetime import datetime
from pathlib import Path
from typing import List, Dict

def extract_entries(content: str) -> List[Dict]:
    """从记忆文件中提取条目"""
    entries = []
    
    # 匹配 ## 开头的条目
    pattern = r'##\s*(?:\[[^\]]+\])?\s*([^\n]+)\n((?:(?!##).)*)'
    
    for match in re.finditer(pattern, content, re.DOTALL):
        title = match.group(1).strip()
        body = match.group(2).strip()
        
        # 提取标签
        tags = re.findall(r'#(\w+)', body)
        
        # 提取来源
        source_match = re.search(r'📝来源[：:]\s*([^\n]+)', body)
        source = source_match.group(1) if source_match else None
        
        # 提取关联
        links = re.findall(r'🔗关联[：:]\s*([^\n]+)', body)
        
        entries.append({
            "title": title,
            "body": body,
            "tags": tags,
            "source": source,
            "links": links
        })
    
    return entries

def categorize_entries(entries: List[Dict]) -> Dict[str, List[Dict]]:
    """按分类组织条目"""
    categories = {
        "重要决策": [],
        "待办任务": [],
        "经验教训": [],
        "项目进展": [],
        "人物互动": [],
        "技术学习": [],
        "其他": []
    }
    
    for entry in entries:
        tags = entry.get("tags", [])
        
        if "重要" in tags or "决策" in str(entry["title"]):
            categories["重要决策"].append(entry)
        elif "待办" in tags:
            categories["待办任务"].append(entry)
        elif "经验" in tags:
            categories["经验教训"].append(entry)
        elif "项目" in tags:
            categories["项目进展"].append(entry)
        elif "人物" in tags:
            categories["人物互动"].append(entry)
        elif "技术" in tags:
            categories["技术学习"].append(entry)
        else:
            categories["其他"].append(entry)
    
    return {k: v for k, v in categories.items() if v}

def generate_summary(file_path: Path, title: str = None) -> str:
    """生成记忆摘要"""
    content = file_path.read_text(encoding='utf-8')
    entries = extract_entries(content)
    
    if not entries:
        return "# Summary\n\nNo memory entries"
    
    # 提取日期
    date_match = re.search(r'(\d{4}-\d{2}-\d{2})', file_path.stem)
    date_str = date_match.group(1) if date_match else datetime.now().strftime("%Y-%m-%d")
    
    # 按分类组织
    categorized = categorize_entries(entries)
    
    # 生成摘要
    summary_lines = [
        f"# Memory Summary - {title or date_str}",
        "",
        f"**Date**: {date_str}",
        f"**Entries**: {len(entries)}",
        "",
        "---",
        ""
    ]
    
    # 重要决策
    if "重要决策" in categorized:
        summary_lines.append("## Important Decisions")
        for e in categorized["重要决策"]:
            summary_lines.append(f"- **{e['title']}**")
            # 提取关键句子
            first_line = e["body"].split('\n')[0][:100]
            summary_lines.append(f"  - {first_line}...")
        summary_lines.append("")
    
    # 待办任务
    if "待办任务" in categorized:
        summary_lines.append("## TODO Tasks")
        for e in categorized["待办任务"]:
            summary_lines.append(f"- [ ] {e['title']}")
        summary_lines.append("")
    
    # 经验教训
    if "经验教训" in categorized:
        summary_lines.append("## Lessons Learned")
        for e in categorized["经验教训"]:
            summary_lines.append(f"- **{e['title']}**")
        summary_lines.append("")
    
    # 项目进展
    if "项目进展" in categorized:
        summary_lines.append("## Project Progress")
        for e in categorized["项目进展"]:
            summary_lines.append(f"- {e['title']}")
        summary_lines.append("")
    
    # 所有标签统计
    all_tags = []
    for e in entries:
        all_tags.extend(e.get("tags", []))
    
    if all_tags:
        from collections import Counter
        tag_counts = Counter(all_tags)
        summary_lines.append("## Tag Statistics")
        for tag, count in tag_counts.most_common(10):
            summary_lines.append(f"- {tag}: {count}")
        summary_lines.append("")
    
    # 来源统计
    sources = [e["source"] for e in entries if e["source"]]
    if sources:
        summary_lines.append("## Sources")
        for src in set(sources):
            summary_lines.append(f"- {src}")
        summary_lines.append("")
    
    return "\n".join(summary_lines)

def generate_multi_file_summary(dir_path: Path, output_file: Path = None) -> str:
    """为多个记忆文件生成汇总摘要"""
    memory_files = sorted(dir_path.glob("memory/YYYY-MM-DD.md"))
    
    if not memory_files:
        # 尝试不带 memory/ 前缀
        memory_files = sorted(dir_path.glob("*.md"))
    
    # 取最近7天的文件
    recent_files = sorted(memory_files, reverse=True)[:7]
    
    all_entries = []
    
    for f in recent_files:
        content = f.read_text(encoding='utf-8')
        entries = extract_entries(content)
        for e in entries:
            e["source_file"] = f.name
        all_entries.extend(entries)
    
    categorized = categorize_entries(all_entries)
    
    summary_lines = [
        f"# Weekly Memory Summary",
        "",
        f"**Period**: Last {len(recent_files)} days",
        f"**Total entries**: {len(all_entries)}",
        "",
        "---",
        ""
    ]
    
    for category, entries in categorized.items():
        summary_lines.append(f"## {category} ({len(entries)} entries)")
        for e in entries[:5]:  # 每类最多显示5条
            summary_lines.append(f"- {e['title']}  `[{e.get('source_file', '')}]`")
        if len(entries) > 5:
            summary_lines.append(f"  ... and {len(entries)-5} more")
        summary_lines.append("")
    
    return "\n".join(summary_lines)

def main():
    parser = argparse.ArgumentParser(description='记忆摘要生成器')
    parser.add_argument('--file', '-f', help='单个记忆文件')
    parser.add_argument('--dir', '-d', help='记忆目录')
    parser.add_argument('--output', '-o', help='输出文件路径')
    parser.add_argument('--title', '-t', help='自定义标题')
    
    args = parser.parse_args()
    
    if args.file:
        file_path = Path(args.file)
        summary = generate_summary(file_path, args.title)
    elif args.dir:
        dir_path = Path(args.dir)
        summary = generate_multi_file_summary(dir_path)
    else:
        print("错误：需要指定 --file 或 --dir")
        sys.exit(1)
    
    if args.output:
        output_path = Path(args.output)
        output_path.write_text(summary, encoding='utf-8')
        print(f"✅ 已保存到: {output_path}")
    else:
        print(summary)

if __name__ == "__main__":
    main()
