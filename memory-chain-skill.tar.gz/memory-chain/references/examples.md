# Memory Chain 使用示例

## 基本操作

### 1. 添加初始记忆 (L1)
```python
mc.add_memory(
    content="今天天气晴朗",
    layer=1,
    tags=["weather", "daily"]
)
```

### 2. 添加情绪记忆 (L2)
```python
mc.add_memory(
    content="用户今天很开心，完成了重要任务",
    layer=2,
    tags=["achievement", "emotion:happy"],
    link_to=["2026-03-16"]
)
```

### 3. 添加场景记忆 (L3)
```python
mc.add_memory(
    content="在会议上讨论了新项目计划",
    layer=3,
    tags=["scene:work", "meeting"],
    metadata={"platform": "zoom"}
)
```

### 4. 语义检索
```python
# 检索所有关于用户偏好的记忆
results = mc.search(
    "用户偏好",
    layer_filter=[4, 5, 6],  # 只看语义层以上
    limit=5
)
```

### 5. 对话归档
```python
messages = [
    {"content": "用户: 记忆链英文怎么说", "role": "user"},
    {"content": "Memory Chain", "role": "assistant"}
]
mc.archive_chat(messages)
```

### 6. 生成周报
```python
summary = mc.summarize(days=7)
# 输出:
# {
#   "period_days": 7,
#   "total_memories": 15,
#   "by_layer": {"情绪记忆": 5, "场景记忆": 3, ...},
#   "keywords": ["project", "work", "emotion:happy", ...]
# }
```

## 实际场景

### 记录用户偏好
```python
# 用户表示喜欢简洁的回复风格
mc.add_memory(
    content="用户喜欢简洁直接的回复风格",
    layer=4,  # 语义记忆
    tags=["preference", "style", "communication"]
)
```

### 跨会话记忆
```python
# 后续会话检索
results = mc.search("用户沟通偏好")
# 自动返回之前的偏好记忆
```

### 记录项目进度
```python
mc.add_memory(
    content="项目A已完成第一阶段开发",
    layer=3,
    tags=["project", "milestone", "development"],
    importance=7
)
```

### 记录学习笔记
```python
mc.add_memory(
    content="学习了Python异步编程的基本概念",
    layer=4,
    tags=["learning", "python", "async"]
)
```
