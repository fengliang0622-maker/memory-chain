# Memory Chain 数据结构

## 记忆对象结构

```json
{
  "id": "20260316104430_001",
  "content": "记忆内容",
  "layer": 2,
  "layer_name": "情绪记忆",
  "tags": ["tag1", "tag2"],
  "links": ["20260315103000_005"],
  "metadata": {
    "source": "chat",
    "author": "亮总"
  },
  "created_at": "2026-03-16T10:44:30",
  "accessed_count": 5
}
```

## 层级说明

### L1 初始记忆
- 碎片化信息
- 原始数据输入
- 无情感色彩

### L2 情绪记忆
- 带情感色彩
- 标记情绪标签: emotion:happy, emotion:sad, emotion:angry

### L3 场景记忆
- 情境化存储
- 关联时间、地点

### L4 语义记忆
- 抽象概念化
- 提取关键概念

### L5 自我认知
- "我是谁"
- 身份认同

### L6 价值观与信念
- 人生观世界观
- 核心原则
