# Memory Chain 使用示例

## 基本操作

### 1. 添加初始记忆 (L1)
```python
mc.add_memory(
    content="今天天气晴朗",
    layer=1,
    tags=["weather", "daily"]
)
```

### 2. 添加情绪记忆 (L2)
```python
mc.add_memory(
    content="亮总今天很开心，给虾起了名字",
    layer=2,
    tags=["creator", "emotion:happy"],
    link_to=["2026-03-11"]
)
```

### 3. 添加场景记忆 (L3)
```python
mc.add_memory(
    content="在QQ上讨论记忆链功能",
    layer=3,
    tags=["scene:work", "qq"],
    metadata={"platform": "qqbot"}
)
```

### 4. 语义检索
```python
# 检索所有关于亮总偏好的记忆
results = mc.search(
    "亮总偏好",
    layer_filter=[4, 5, 6],  # 只看语义层以上
    limit=5
)
```

### 5. 对话归档
```python
messages = [
    {"content": "亮总: 记忆链英文怎么说", "role": "user"},
    {"content": "Memory Chain", "role": "assistant"}
]
mc.archive_chat(messages)
```

### 6. 生成周报
```python
summary = mc.summarize(days=7)
# 输出:
# {
#   "period_days": 7,
#   "total_memories": 15,
#   "by_layer": {"情绪记忆": 5, "场景记忆": 3, ...},
#   "keywords": ["creator", "xhs", "emotion:happy", ...]
# }
```

## 实际场景

### 记录用户偏好
```python
# 亮总说喜欢押韵的歌词
mc.add_memory(
    content="亮总喜欢押韵密集的歌词",
    layer=4,  # 语义记忆
    tags=["preference", "lyrics", "rhyme"]
)
```

### 跨会话记忆
```python
# 后续会话检索
results = mc.search("亮总歌词偏好")
# 自动返回之前的偏好记忆
```
