#!/usr/bin/env python3
"""
Memory Chain CLI - 命令行工具
"""

import argparse
import json
import sys
from pathlib import Path

# 添加脚本目录到路径
sys.path.insert(0, str(Path(__file__).parent))

from memory_chain import MemoryChain

def main():
    parser = argparse.ArgumentParser(description="Memory Chain CLI")
    subparsers = parser.add_subparsers(dest="command", help="命令")
    
    # add 命令
    add_parser = subparsers.add_parser("add", help="添加记忆")
    add_parser.add_argument("content", help="记忆内容")
    add_parser.add_argument("-l", "--layer", type=int, default=1, help="记忆层级(1-6)")
    add_parser.add_argument("-t", "--tags", nargs="+", help="标签")
    
    # search 命令
    search_parser = subparsers.add_parser("search", help="搜索记忆")
    search_parser.add_argument("query", help="搜索关键词")
    search_parser.add_argument("-l", "--layer", type=int, nargs="+", help="层级过滤")
    
    # stats 命令
    subparsers.add_parser("stats", help="查看统计")
    
    # summarize 命令
    sum_parser = subparsers.add_parser("summarize", help="生成摘要")
    sum_parser.add_argument("-d", "--days", type=int, default=7, help="天数")
    sum_parser.add_argument("-l", "--layer", type=int, help="层级")
    
    args = parser.parse_args()
    
    mc = MemoryChain()
    
    if args.command == "add":
        memory_id = mc.add_memory(
            content=args.content,
            layer=args.layer,
            tags=args.tags
        )
        print(f"✅ 记忆已添加: {memory_id}")
    
    elif args.command == "search":
        results = mc.search(args.query, layer_filter=args.layer)
        print(f"🔍 找到 {len(results)} 条记忆:")
        for r in results:
            print(f"  [{r['layer_name']}] {r['content'][:50]}...")
    
    elif args.command == "stats":
        stats = mc.get_layer_stats()
        print("📊 记忆统计:")
        for layer, count in stats.items():
            print(f"  L{layer}: {count}条")
    
    elif args.command == "summarize":
        summary = mc.summarize(days=args.days, layer=args.layer)
        print(f"📝 {args.days}天摘要:")
        print(f"  总记忆: {summary['total_memories']}条")
        print(f"  按层级: {summary['by_layer']}")
        print(f"  关键词: {summary['keywords'][:10]}")
    
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
