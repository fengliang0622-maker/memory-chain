#!/usr/bin/env python3
"""
Memory Chain - 六层记忆架构核心引擎
"""

import json
import os
import re
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any
from pathlib import Path

class MemoryChain:
    """六层记忆架构引擎"""
    
    LAYERS = {
        1: "初始记忆",
        2: "情绪记忆", 
        3: "场景记忆",
        4: "语义记忆",
        5: "自我认知",
        6: "价值观与信念"
    }
    
    def __init__(self, storage_path: str = None):
        self.storage_path = storage_path or "./memory_data.json"
        self.memories = self._load()
    
    def _load(self) -> List[Dict]:
        """加载记忆"""
        if os.path.exists(self.storage_path):
            with open(self.storage_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return []
    
    def _save(self):
        """保存记忆"""
        with open(self.storage_path, 'w', encoding='utf-8') as f:
            json.dump(self.memories, f, ensure_ascii=False, indent=2)
    
    def add_memory(
        self, 
        content: str, 
        layer: int = 1,
        tags: List[str] = None,
        link_to: List[str] = None,
        metadata: Dict[str, Any] = None
    ) -> str:
        """添加记忆"""
        memory_id = f"{datetime.now().strftime('%Y%m%d%H%M%S')}_{len(self.memories)}"
        
        memory = {
            "id": memory_id,
            "content": content,
            "layer": layer,
            "layer_name": self.LAYERS.get(layer, "未知"),
            "tags": tags or [],
            "links": link_to or [],
            "metadata": metadata or {},
            "created_at": datetime.now().isoformat(),
            "accessed_count": 0
        }
        
        self.memories.append(memory)
        self._save()
        
        # 自动触发关联
        self._auto_link(memory_id, content)
        
        return memory_id
    
    def _auto_link(self, memory_id: str, content: str):
        """自动关联相关记忆"""
        memory = self.get(memory_id)
        if not memory:
            return
        
        new_links = []
        for m in self.memories:
            if m["id"] == memory_id:
                continue
            # 简单关键词匹配
            common = set(m["tags"]) & set(memory.get("tags", []))
            if common and m["id"] not in memory.get("links", []):
                # 双向链接
                if m["id"] not in new_links:
                    new_links.append(m["id"])
                if memory_id not in m["links"]:
                    m["links"].append(memory_id)
        
        # 更新新记忆的links
        if new_links:
            memory["links"] = new_links
        
        self._save()
    
    def get(self, memory_id: str) -> Optional[Dict]:
        """获取单条记忆"""
        for m in self.memories:
            if m["id"] == memory_id:
                m["accessed_count"] += 1
                self._save()
                return m
        return None
    
    def search(
        self, 
        query: str, 
        layer_filter: List[int] = None,
        tags: List[str] = None,
        limit: int = 10
    ) -> List[Dict]:
        """语义检索"""
        results = []
        
        for m in self.memories:
            # 层級过滤
            if layer_filter and m["layer"] not in layer_filter:
                continue
            
            # 标签过滤
            if tags:
                if not any(t in m["tags"] for t in tags):
                    continue
            
            # 内容匹配
            score = 0
            if query in m["content"]:
                score += 10
            score += m["accessed_count"] * 0.1
            
            results.append((score, m))
        
        results.sort(key=lambda x: x[0], reverse=True)
        return [r[1] for r in results[:limit]]
    
    def summarize(
        self, 
        days: int = 7,
        layer: int = None
    ) -> Dict[str, Any]:
        """生成摘要"""
        cutoff = datetime.now() - timedelta(days=days)
        recent = []
        
        for m in self.memories:
            created = datetime.fromisoformat(m["created_at"])
            if created >= cutoff:
                if layer is None or m["layer"] == layer:
                    recent.append(m)
        
        # 按层级统计
        by_layer = {}
        for m in recent:
            layer_name = m["layer_name"]
            if layer_name not in by_layer:
                by_layer[layer_name] = []
            by_layer[layer_name].append(m)
        
        # 提取关键词
        all_tags = set()
        for m in recent:
            all_tags.update(m["tags"])
        
        return {
            "period_days": days,
            "total_memories": len(recent),
            "by_layer": {k: len(v) for k, v in by_layer.items()},
            "keywords": list(all_tags)[:20],
            "memories": recent
        }
    
    def archive_chat(self, messages: List[Dict]) -> str:
        """对话归档 - 自动提取关键信息"""
        key_info = {
            "entities": set(),
            "emotions": set(),
            "topics": set()
        }
        
        for msg in messages:
            content = msg.get("content", "")
            # 简单提取 #标签
            tags = re.findall(r'#(\w+)', content)
            key_info["topics"].update(tags)
        
        # 创建记忆
        memory_id = self.add_memory(
            content=f"对话归档: {len(messages)}条消息",
            layer=3,  # 场景记忆
            tags=list(key_info["topics"]),
            metadata={"message_count": len(messages)}
        )
        
        return memory_id
    
    def get_layer_stats(self) -> Dict[int, int]:
        """获取各层级统计"""
        stats = {i: 0 for i in range(1, 7)}
        for m in self.memories:
            stats[m["layer"]] += 1
        return stats


if __name__ == "__main__":
    # CLI 测试
    mc = MemoryChain()
    
    # 添加示例记忆
    mc.add_memory(
        content="亮总给AI助手起名仙女虾",
        layer=2,
        tags=["creator", "name", "emotion:happy"],
        link_to=["2026-03-11"]
    )
    
    print("当前记忆统计:", mc.get_layer_stats())
    print("检索结果:", mc.search("亮总"))
