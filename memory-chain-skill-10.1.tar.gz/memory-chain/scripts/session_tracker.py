#!/usr/bin/env python3
"""
会话结束自动触发器
当检测到会话结束时，自动归档对话到记忆链

触发条件：
1. 会话结束关键词（再见、拜拜等）
2. 1小时无对话自动归档  
3. 每天12点定时归档（每天最多一次）
"""

import sys
import os
import json
import time
from datetime import datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from memory_chain import MemoryChain

# 会话结束关键词
END_KEYWORDS = [
    "再见", "拜拜", "晚安", "有事", "先忙", "走了",
    "goodbye", "bye", "see you", "晚点聊",
    "先这样", "就这样", "结束", "END"
]

# 消息阈值（超过此数量认为可能需要归档）
MESSAGE_THRESHOLD = 3

# 无对话超时时间（秒）
IDLE_TIMEOUT = 3600  # 1小时

# 定时归档配置文件
ARCHIVE_CONFIG_PATH = "./archive_config.json"


def load_archive_config() -> dict:
    """加载归档配置"""
    if os.path.exists(ARCHIVE_CONFIG_PATH):
        with open(ARCHIVE_CONFIG_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {"last_daily_archive": None}


def save_archive_config(config: dict):
    """保存归档配置"""
    with open(ARCHIVE_CONFIG_PATH, 'w', encoding='utf-8') as f:
        json.dump(config, f, ensure_ascii=False, indent=2)


def detect_session_end(message: str) -> bool:
    """检测是否是会话结束语"""
    message_lower = message.lower()
    for keyword in END_KEYWORDS:
        if keyword.lower() in message_lower:
            return True
    return False


def check_idle_archive(messages: list) -> bool:
    """检查是否超时无对话需要归档"""
    if not messages:
        return False
    
    try:
        last_msg_time = datetime.fromisoformat(messages[-1].get("timestamp", messages[-1].get("created_at", "")))
        # 如果没有时间戳，尝试从消息中获取或跳过
    except:
        # 没有时间戳信息，不触发超时归档
        return False
    
    now = datetime.now()
    idle_seconds = (now - last_msg_time).total_seconds()
    
    return idle_seconds >= IDLE_TIMEOUT and len(messages) >= MESSAGE_THRESHOLD


def check_daily_archive() -> bool:
    """检查今天是否已经定时归档过"""
    config = load_archive_config()
    today = datetime.now().strftime("%Y-%m-%d")
    
    if config.get("last_daily_archive") == today:
        return True  # 今天已经归档过了
    
    return False


def mark_daily_archive_done():
    """标记今天已经完成定时归档"""
    config = load_archive_config()
    config["last_daily_archive"] = datetime.now().strftime("%Y-%m-%d")
    save_archive_config(config)


def should_archive(messages: list, force: bool = False) -> dict:
    """判断是否需要归档，返回触发原因"""
    if force:
        return {"should": len(messages) >= 1, "reason": "强制归档"}
    
    if len(messages) < MESSAGE_THRESHOLD:
        return {"should": False, "reason": "消息不足"}
    
    # 检查1: 会话结束关键词
    if messages:
        last_msg = messages[-1].get("content", "")
        if detect_session_end(last_msg):
            return {"should": True, "reason": "会话结束"}
    
    # 检查2: 超时无对话
    if check_idle_archive(messages):
        return {"should": True, "reason": "1小时无对话"}
    
    # 检查3: 每天12点定时归档
    now = datetime.now()
    if now.hour == 0 and not check_daily_archive():  # 0点触发（晚上12点）
        return {"should": True, "reason": "定时归档"}
    
    return {"should": False, "reason": None}


def archive_current_session(messages: list, session_name: str = "default", reason: str = "manual") -> str:
    """归档当前会话"""
    mc = MemoryChain()
    
    if not messages:
        return None
    
    # 提取关键信息
    user_count = len([m for m in messages if m.get("role") == "user"])
    assistant_count = len([m for m in messages if m.get("role") == "assistant"])
    
    # 提取所有文本和标签
    all_text = " ".join([m.get("content", "") for m in messages])
    import re
    tags = re.findall(r'#(\w+)', all_text)
    
    # 提取关键词
    keywords = []
    important = ["记忆", "小红书", "歌词", "创作", "skill", "亮总", "仙女虾"]
    for word in important:
        if word in all_text:
            keywords.append(word)
    
    # 自动判断层级
    if any(e in all_text for e in ["开心", "高兴", "喜欢", "爱", "棒", "帅", "谢谢"]):
        layer = 2
    elif len(messages) > 10:
        layer = 3
    else:
        layer = 1
    
    # 创建归档记忆
    memory_id = mc.add_memory(
        content=f"会话[{session_name}]归档({reason}): {len(messages)}条 ({user_count}用户/{assistant_count}助手)",
        layer=layer,
        tags=list(set(tags + keywords + ["会话", "归档"])),
        metadata={
            "session_name": session_name,
            "message_count": len(messages),
            "user_count": user_count,
            "assistant_count": assistant_count,
            "type": "session_archive",
            "reason": reason,
            "archived_at": datetime.now().isoformat()
        }
    )
    
    return memory_id


def init_session_tracker(session_name: str = "default", storage_path: str = None):
    """初始化会话追踪器"""
    storage_path = storage_path or f"./session_{session_name}.json"
    
    # 初始化空会话
    if not os.path.exists(storage_path):
        with open(storage_path, 'w', encoding='utf-8') as f:
            json.dump({
                "messages": [], 
                "session_name": session_name,
                "last_message_time": None
            }, f)
    
    return storage_path


def add_message(session_name: str, message: dict, storage_path: str = None):
    """添加消息到当前会话"""
    storage_path = storage_path or f"./session_{session_name}.json"
    
    if not os.path.exists(storage_path):
        init_session_tracker(session_name, storage_path)
    
    with open(storage_path, 'r', encoding='utf-8') as f:
        session_data = json.load(f)
    
    # 添加时间戳
    message["timestamp"] = datetime.now().isoformat()
    session_data["messages"].append(message)
    session_data["last_message_time"] = message["timestamp"]
    
    with open(storage_path, 'w', encoding='utf-8') as f:
        json.dump(session_data, f, ensure_ascii=False, indent=2)
    
    # 检查是否需要归档
    check_result = should_archive(session_data["messages"])
    
    if check_result["should"]:
        memory_id = archive_current_session(
            session_data["messages"], 
            session_name,
            reason=check_result["reason"]
        )
        
        # 归档后清空会话
        session_data["messages"] = []
        with open(storage_path, 'w', encoding='utf-8') as f:
            json.dump(session_data, f, ensure_ascii=False, indent=2)
        
        # 如果是定时归档，标记已完成
        if check_result["reason"] == "定时归档":
            mark_daily_archive_done()
        
        return memory_id
    
    return None


def daily_archive_all():
    """定时归档所有会话（每天0点调用）"""
    if check_daily_archive():
        print("今天已经归档过了，跳过")
        return
    
    # 查找所有会话文件
    import glob
    session_files = glob.glob("./session_*.json")
    
    archived_count = 0
    for sf in session_files:
        with open(sf, 'r', encoding='utf-8') as f:
            session_data = json.load(f)
        
        messages = session_data.get("messages", [])
        if len(messages) >= MESSAGE_THRESHOLD:
            session_name = session_data.get("session_name", "unknown")
            archive_current_session(messages, session_name, "定时归档")
            archived_count += 1
            
            # 清空会话
            session_data["messages"] = []
            with open(sf, 'w', encoding='utf-8') as f:
                json.dump(session_data, f, ensure_ascii=False, indent=2)
    
    if archived_count > 0:
        mark_daily_archive_done()
        print(f"✅ 定时归档完成: {archived_count}个会话")
    else:
        print("没有需要归档的会话")


# 测试
if __name__ == "__main__":
    # 测试1: 会话结束关键词触发
    test_messages = [
        {"content": "亮总问: 记忆链英文怎么说", "role": "user", "timestamp": datetime.now().isoformat()},
        {"content": "Memory Chain", "role": "assistant", "timestamp": datetime.now().isoformat()},
        {"content": "亮总说: 再见", "role": "user", "timestamp": datetime.now().isoformat()},
    ]
    
    print("=" * 30)
    print("测试1 - 会话结束关键词:")
    result = should_archive(test_messages)
    print(f"  结果: {result}")
    
    # 测试2: 1小时无对话触发
    old_time = (datetime.now() - timedelta(hours=2)).isoformat()
    test_idle = [
        {"content": "亮总问: 在吗", "role": "user", "timestamp": old_time},
        {"content": "虾: 在的", "role": "assistant", "timestamp": old_time},
    ]
    
    print("=" * 30)
    print("测试2 - 1小时无对话:")
    result = should_archive(test_idle)
    print(f"  结果: {result}")
    
    # 测试3: 检查每日归档
    print("=" * 30)
    print("测试3 - 每日归档检查:")
    print(f"  今天已归档: {check_daily_archive()}")
    
    print("=" * 30)
    print("✅ 所有测试通过！")
