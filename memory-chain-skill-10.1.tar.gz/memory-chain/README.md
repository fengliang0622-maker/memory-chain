# Memory Chain - 六层记忆架构

基于人类记忆科学设计的AI记忆系统，模拟从碎片信息到价值观形成的完整记忆过程。

## 🌟 特性

- 🧠 **6层记忆架构** - 初始记忆 → 情绪记忆 → 场景记忆 → 语义记忆 → 自我认知 → 价值观
- 🔗 **自动关联** - 发现并链接相关记忆，形成知识网络
- 🏷️ **智能分类** - 自动识别内容类型打标签
- 🔍 **语义检索** - 快速调取需要的记忆
- 📝 **摘要生成** - 结构化整理记忆
- 💬 **对话归档** - 自动提取对话中的关键信息

## 📁 目录结构

```
memory-chain/
├── SKILL.md              # 技能定义 + 使用说明
├── scripts/
│   ├── memory_chain.py   # 核心引擎
│   ├── cli.py            # 命令行工具
│   ├── auto_archive.py   # 自动归档
│   └── session_tracker.py # 会话追踪 + 自动触发
└── references/
    ├── schema.md         # 数据结构定义
    └── examples.md       # 使用示例
```

## 🚀 快速开始

### 安装

```bash
# 克隆或下载
git clone https://github.com/your-repo/memory-chain.git
cd memory-chain
```

### 基本使用

```python
from scripts.memory_chain import MemoryChain

mc = MemoryChain()

# 添加记忆
mc.add_memory(
    content="今天学到了新东西",
    layer=1,
    tags=["学习", "新知识"]
)

# 搜索记忆
results = mc.search("学习")

# 生成摘要
summary = mc.summarize(days=7)
```

### 命令行

```bash
# 添加记忆
python3 scripts/cli.py add "内容" -l 2 -t tag1 tag2

# 搜索
python3 scripts/cli.py search "关键词"

# 统计
python3 scripts/cli.py stats

# 摘要
python3 scripts/cli.py summarize -d 7
```

## 📊 记忆层次

| 层级 | 名称 | 描述 |
|------|------|------|
| L1 | 初始记忆 | 碎片化信息，原始数据 |
| L2 | 情绪记忆 | 带情感色彩的记忆 |
| L3 | 场景记忆 | 情境化存储 |
| L4 | 语义记忆 | 抽象概念化 |
| L5 | 自我认知 | "我是谁" |
| L6 | 价值观与信念 | 人生观世界观 |

## ⚡ 自动触发

1. **会话结束** - 检测到"再见/拜拜/晚安"等关键词
2. **1小时无对话** - 超过1小时没新消息自动归档
3. **每天0点定时** - 每晚12点自动归档（每天最多1次）

## 📝 License

MIT

---

*Built with 🦐 by 仙女虾*
